function addToCart(name, rentPrice, imageUrl) {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];

    cart.push({ name: name, rentPrice: rentPrice, image: imageUrl });

    localStorage.setItem('cart', JSON.stringify(cart));
}
cart.forEach((item, index) => {
    totalAmount += item.rentPrice;

    const div = document.createElement('div');
    div.classList.add('toy-card');
    div.innerHTML = `
      <img src="${item.image}" alt="${item.name}">
      <h3>${item.name}</h3>
      <p>Түрээс: ${item.rentPrice}₮</p>
      <button class="remove-btn" onclick="removeFromCart(${index})">Устгах</button>
    `;
    cartContainer.appendChild(div);
});