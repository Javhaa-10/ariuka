function addToCart(button) {
    const card = button.closest('.toy-card');
    const name = card.querySelector('h3').innerText;
    const imageUrl = card.querySelector('img').src;
    const priceText = card.querySelector('.price').innerText;

    // Үнэ: 25000₮ гэсэн текстээс тоог салгаж авна
    const price = parseInt(priceText.replace(/[^\d]/g, ''));

    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart.push({ name, price, image: imageUrl, type: 'buy' }); // type: 'buy' гэдгээр ялгаж хадгална

    localStorage.setItem('cart', JSON.stringify(cart));

    alert(`${name} сагсанд нэмэгдлээ!`);
}

function goToCart() {
    window.location.href = 'cart.html';
}